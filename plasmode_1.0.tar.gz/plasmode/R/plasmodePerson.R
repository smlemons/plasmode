plasmodePerson <- function(data, iter=1000, percentage_realdata,
                           saving = FALSE, comparison = fnr){
  ## browser()
  ## stop, when the input is not appropriate 
  stopifnot(is.numeric(iter) & is.numeric(percentage_realdata)
            & percentage_realdata <1 & percentage_realdata >=0 
            & is.data.frame(data)|is.matrix(data) & length(percentage_realdata) >0)
  ## initialise loop
  l_z <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  z.in <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  z.out <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  M_2 <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  RMSEA <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  CFI <- matrix(NA, nrow = length(percentage_realdata), ncol = iter)
  ## create model, extract slope and intercepts
  model <- mirt(data, itemtype = "2PL", technical = list(NCYCLES = 2000), 
                verbose = FALSE)
  a <- coef(model, simplify= TRUE)$items[,1]
  d <- coef(model, simplify= TRUE)$items[,2]
  ## prepare mismatching measures
  prePerson <- personfit(model)$Zh
  preModel <- M2(model)
  initialFit <- list(prePerson = prePerson, preModel = preModel) 
  pers <- abs(prePerson) > qnorm(p=(0.975))
  worstfit <- which(pers)
  n <- nrow(data)
  blocksize <- ceiling(ncol(data)/4)
  block1 <- 1:blocksize
  block2 <-(blocksize+1):(2*blocksize)
  block3 <- (2*blocksize+1): (3*blocksize)
  block4 <- (3*blocksize+1): ncol(data)
  ## results gradually for every components of percentage_realdata
  for(j in 1:length(percentage_realdata)){
    ## determine right amount of real data with worst fit if needed
    worst <- ceiling(percentage_realdata[j] * n)
    ## repeat for every iteration
    for(i in 1:iter){
      ## simulate based on model
      plasSim <- simdata(a=a, d=d, N = (n - worst), itemtype = "dich")
      ## join datasets if needed
      if(percentage_realdata[j] > 0){
        worstreal1 <- sample(x = worstfit, size = worst, replace = TRUE)
        worstreal2 <- sample(x = worstfit, size = worst, replace = TRUE)
        worstreal3 <- sample(x = worstfit, size = worst, replace = TRUE)
        worstreal4 <- sample(x = worstfit, size = worst, replace = TRUE)
        
        if(length(worstfit) == 1){
          worstreal <- rep(x = worstfit, times = worst)
        }
        plasReal <- cbind(data[worstreal1,block1], data[worstreal2,block2], 
                          data[worstreal3,block3], data[worstreal4,block4])
        
        colnames(plasSim) <- colnames(plasReal)
        plas <- rbind(plasReal, plasSim)
        #plas <- matrix(as.numeric(plas), ncol = ncol(data))
      }
      ## otherwise only use sampled datasets
      if(percentage_realdata[j] == 0){
        plas <- plasSim
      }
      colnames(plas) <- 1:ncol(plas)
      modelPlas <- mirt(plas, itemtype = "2PL", technical = list(NCYCLES = 2000), 
                        verbose = FALSE)
      ## calculate relevant statistics (and save them) 
      Lz <- personfit(modelPlas)
      #SX2 <- itemfit(modelPlas, fit_stats = c("S_X2", "infit"))
      M2 <- M2(modelPlas)
      ## first n-worst observations matching, the rest mismatching
      Pers <- c(rep(TRUE, times = n-worst), rep(FALSE, times = worst))
      ## save if necessary
      if(saving == TRUE){
        res <- list(lz = Lz, M2 = M2) 
        save(res, file = paste0("obj_",i,j, ".RData"))}
      ## calculate comparison criteria
      comp <- abs(Lz$Zh) <= qnorm(p=(0.975))
      tp <- sum( comp & Pers == TRUE)
      fn <- sum( !comp & Pers == TRUE)
      l_z[j,i] <- comparison(tp,fn)
      comp <- abs(Lz$z.infit) <= qnorm(p=(0.975))
      tp <- sum( comp & Pers == TRUE)
      fn <- sum( !comp & Pers == TRUE)
      z.in[j,i] <- comparison(tp,fn)
      comp <- abs(Lz$z.outfit) <= qnorm(p=(0.975))
      tp <- sum( comp & Pers == TRUE)
      fn <- sum( !comp & Pers == TRUE)
      z.out[j,i] <- comparison(tp,fn)
      M_2[j, i] <- M2$p 
      RMSEA[j, i] <- M2$RMSEA 
      CFI[j, i] <- M2$CFI 
    }
  }
  ## return result
  res_final <- list(
    preFit = initialFit,
    lz = l_z,
    z.infit = z.in,
    z.outfit = z.out,
    M2 = M_2,
    CFI = CFI,
    RMSEA = RMSEA
  )
  return(res_final)
}



