plasmodeItem <- function(data, iter=1000, number_realitems,
                         saving = FALSE, comparison = fnr){
  #browser()
  ## stop, when the input is not appropriate 
  stopifnot(is.numeric(iter) & is.numeric(number_realitems)
            & number_realitems >= 0 & number_realitems%%1 == 0 
            & is.data.frame(data)|is.matrix(data) & length(number_realitems) >0)
  ## initialise loop
  SX_2 <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  z.inItem <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  z.outItem <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  M_2 <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  RMSEA <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  CFI <- matrix(NA, nrow = length(number_realitems), ncol = iter)
  ## create model, extract slope and intercepts
  model <- mirt(data, itemtype = "2PL", technical = list(NCYCLES = 2000), 
                verbose = FALSE)
  a <- coef(model, simplify= TRUE)$items[,1]
  d <- coef(model, simplify= TRUE)$items[,2]
  ## prepare mismatching measures
  preItem <- itemfit(model)$p.S_X2
  preModel <- M2(model)
  initialFit <- list(preItem = preItem, preModel = preModel)
  it <- preItem <= 0.05
  worstfit <- which(it)
  n <- ncol(data)
  Dist <- as.matrix(dist(data))
  ## results gradually for every components of percentage_realdata
  for(j in 1:length(number_realitems)){
    ## determine right amount of real data with worst fit if needed
    worst <- number_realitems[j]
    ## repeat for every iteration
    for(i in 1:iter){
      ## simulate based on model
      itempool <- 1:n
      itempool <- itempool[-c(worstfit)]
      itempool <- sample(x = itempool, size = (n-worst), replace = TRUE)
      plasSim <- simdata(a=a[itempool], d=d[itempool], N = nrow(data),
                         itemtype = "dich")
      ## join datasets if needed
      if(number_realitems[j] > 0){
        items <- ifelse(rep(length(worstfit)==1, times = worst), rep(worstfit,worst),
                        sample(x = worstfit, size = worst, replace = TRUE))
        plasReal <- as.matrix(data[,items], nrow = nrow(data))
        #if(worst == 1){plasReal <- apply(plasReal,
        #                                      function(i) sample(x = data[which(i %in% dist[order(i)[1:5]])], size =1))}
        #browser()
        for(k in 1:worst){
          for(h in 1:nrow(data)){
            X <- as.numeric(data[which(Dist[,h] %in% Dist[order(Dist[,h]),h][1:5]),items[k]])
            plasReal[h,k] <- sample(x = X, size =1)
          } 
        }
        plas <- cbind(plasSim, plasReal)
        #plas <- matrix(as.numeric(plas), ncol = ncol(data))
      }
      ## otherwise only use sampled datasets
      if(number_realitems[j] == 0){
        plas <- plasSim
      }
      #browser()
      colnames(plas) <- 1:ncol(plas)
      modelPlas <- mirt(plas, itemtype = "2PL", technical = list(NCYCLES = 2000), 
                        verbose = FALSE)
      ## calculate relevant statistics (and save them) 
      SX2 <- itemfit(modelPlas, fit_stats = c("S_X2", "infit"))
      M2 <- M2(modelPlas)
      ## first n-worst observations matching, the rest mismatching
      It <- c(rep(TRUE, times = n-worst), rep(FALSE, times = worst))
      ## save if necessary
      if(saving == TRUE){
        res <- list(SX2 = SX2, M2 = M2) 
        save(res, file = paste0("obj_",i,j, ".RData"))}
      ## calculate comparison criteria
      comp <- SX2$p.S_X2 >= 0.05
      tp <- sum( comp & It == TRUE)
      fn <- sum( !comp & It == TRUE)
      SX_2[j,i] <- comparison(tp,fn)
      comp <- abs(SX2$z.infit) <= qnorm(p=(0.995))
      tp <- sum( comp & It == TRUE)
      fn <- sum( !comp & It == TRUE)
      z.inItem[j,i] <- comparison(tp,fn)
      comp <- abs(SX2$z.outfit) <= qnorm(p=(0.995))
      tp <- sum( comp & It == TRUE)
      fn <- sum( !comp & It == TRUE)
      z.outItem[j,i] <- comparison(tp,fn)
      M_2[j, i] <- M2$p 
      RMSEA[j, i] <- M2$RMSEA 
      CFI[j, i] <- M2$CFI 
    }
  }
  ## return result
  res_final <- list(
    preFit = initialFit,
    SX_2 = SX_2,
    z.inItem = z.inItem,
    z.outItem = z.outItem,
    M2 = M_2,
    CFI = CFI,
    RMSEA = RMSEA
  )
  return(res_final)
}

