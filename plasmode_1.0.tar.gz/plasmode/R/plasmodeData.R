## Input: data - dichotomous data frame or matrix with items as columns and 
##               participants as rows
##        number - number of needed datasets per component of realdata (default = 1)
##        realdata - number of real data in the plasmode simulation,
##                           vector with at least one component, every component
##                           as natural number 
##                              
##        type - if set to "person" (default), the data is merged on person level,
##               if set to "item", the data is merged on item level

## Output: List with resulting comparison criteria as components for each statistic
##         and each iteration (columns for iterations and rows for different components of 
##         percentage of real data)
##         Additional list component: fit statistics of initial model


plasmodeData <- function(data, number=1, realdata = 0, type = "person"){
  ## stop, when the input is not appropriate 
  stopifnot(is.numeric(number) & is.numeric(realdata) & number %%1 == 0
            & realdata >= 0 & is.data.frame(data)|is.matrix(data) 
            & length(realdata) >0 & number >0 & length(realdata) >0)
  ## create model, extract slope and intercepts
  model <- mirt(data, itemtype = "2PL", technical = list(NCYCLES = 2000), 
                verbose = FALSE)
  a <- coef(model, simplify= TRUE)$items[,1]
  d <- coef(model, simplify= TRUE)$items[,2]
  res <- list()
  ## prepare mismatching measures
  if(type == "item"){
  stopifnot(realdata%%1 ==0)
  preItem <- itemfit(model)$p.S_X2
  it <- preItem <= 0.05
  worstfit <- which(it)
  n <- ncol(data)
  Dist <- as.matrix(dist(data))
  ## results gradually for every components of realdata
  for(j in 1:length(realdata)){
    ## determine right amount of real data with worst fit if needed
    worst <- realdata[j]
    ## repeat for every iteration
    for(i in 1:number){
      ## simulate based on model
      itempool <- 1:n
      itempool <- itempool[-c(worstfit)]
      itempool <- sample(x = itempool, size = (n-worst), replace = TRUE)
      plasSim <- simdata(a=a[itempool], d=d[itempool], N = nrow(data),
                         itemtype = "dich")
      ## join datasets if needed
      if(realdata[j] > 0){
        items <- ifelse(rep(length(worstfit)==1, times = worst), rep(worstfit,worst),
                        sample(x = worstfit, size = worst, replace = TRUE))
        plasReal <- as.matrix(data[,items], nrow = nrow(data))
        #if(worst == 1){plasReal <- apply(plasReal,
        #                                      function(i) sample(x = data[which(i %in% dist[order(i)[1:5]])], size =1))}
        for(k in 1:worst){
          for(h in 1:nrow(data)){
            X <- as.numeric(data[which(Dist[,h] %in% Dist[order(Dist[,h]),h][1:5]),items[k]])
            plasReal[h,k] <- sample(x = X, size =1)
          } 
        }
        plas <- cbind(plasSim, plasReal)
        #plas <- matrix(as.numeric(plas), ncol = ncol(data))
      }
      ## otherwise only use sampled datasets
      if(realdata[j] == 0){
        plas <- plasSim
      }
      res[[i+(j-1)*number]] <- plas
    }}}
  if(type == "person"){
    stopifnot(realdata <1)
    ## prepare mismatching measures
    prePerson <- personfit(model)$Zh
    preModel <- M2(model)
    initialFit <- list(prePerson = prePerson, preModel = preModel) 
    pers <- abs(prePerson) > qnorm(p=(0.975))
    worstfit <- which(pers)
    n <- nrow(data)
    blocksize <- ceiling(ncol(data)/4)
    block1 <- 1:blocksize
    block2 <-(blocksize+1):(2*blocksize)
    block3 <- (2*blocksize+1): (3*blocksize)
    block4 <- (3*blocksize+1): ncol(data)
    ## results gradually for every components of realdata
    for(j in 1:length(realdata)){
      ## determine right amount of real data with worst fit if needed
      worst <- ceiling(realdata[j] * n)
      ## repeat for every iteration
      for(i in 1:number){
        ## simulate based on model
        plasSim <- simdata(a=a, d=d, N = (n - worst), itemtype = "dich")
        ## join datasets if needed
        if(realdata[j] > 0){
          worstreal1 <- sample(x = worstfit, size = worst, replace = TRUE)
          worstreal2 <- sample(x = worstfit, size = worst, replace = TRUE)
          worstreal3 <- sample(x = worstfit, size = worst, replace = TRUE)
          worstreal4 <- sample(x = worstfit, size = worst, replace = TRUE)
          
          if(length(worstfit) == 1){
            worstreal <- rep(x = worstfit, times = worst)
          }
          plasReal <- cbind(data[worstreal1,block1], data[worstreal2,block2], 
                            data[worstreal3,block3], data[worstreal4,block4])
          
          colnames(plasSim) <- colnames(plasReal)
          plas <- rbind(plasReal, plasSim)
          #plas <- matrix(as.numeric(plas), ncol = ncol(data))
        }
        ## otherwise only use sampled datasets
        if(realdata[j] == 0){
          plas <- plasSim
        }
        res[[i+(j-1)*number]] <- plas
      }
    }
  }
  return(res)
  }

