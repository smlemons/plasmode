fnr <- function(tp,fn){
  res <- fn/(tp+fn)
  return(res)
}
